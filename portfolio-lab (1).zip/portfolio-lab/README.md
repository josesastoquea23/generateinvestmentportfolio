# Portfolio Lab 🚀

Motor institucional de análisis de portafolios con IA.

---

## Cómo correrlo localmente

Necesitas tener [Node.js](https://nodejs.org) instalado (versión 18 o superior).

```bash
# 1. Instalar dependencias
npm install

# 2. Correr en modo desarrollo
npm run dev
```

Abre http://localhost:5173 en tu navegador.

---

## Cómo desplegarlo gratis en Vercel (link permanente)

### Opción A — Desde GitHub (recomendado)

1. Sube esta carpeta a un repositorio en [github.com](https://github.com)
2. Ve a [vercel.com](https://vercel.com) → **Add New Project**
3. Conecta tu cuenta de GitHub y selecciona el repositorio
4. Vercel detecta Vite automáticamente → click en **Deploy**
5. En ~1 minuto tienes tu link tipo `portfolio-lab.vercel.app`

### Opción B — Desde la CLI de Vercel (más rápido)

```bash
# Instalar Vercel CLI
npm install -g vercel

# Dentro de esta carpeta, ejecutar:
vercel

# Seguir los pasos en pantalla
# Al finalizar te da el link directo
```

---

## Cómo desplegarlo en Netlify

1. Ve a [netlify.com](https://netlify.com) → **Add new site** → **Deploy manually**
2. Ejecuta primero `npm run build` — genera la carpeta `dist/`
3. Arrastra la carpeta `dist/` al panel de Netlify
4. Listo, tienes tu link

---

## Estructura del proyecto

```
portfolio-lab/
├── index.html              # Entry point HTML
├── package.json            # Dependencias
├── vite.config.js          # Configuración Vite
└── src/
    ├── main.jsx            # Entry point React
    └── PortfolioAnalyzer.jsx  # Componente principal
```

---

## Privacidad

Para proteger tu app con contraseña en Vercel:
- Ve a tu proyecto → **Settings** → **Deployment Protection**
- Activa **Password Protection** e ingresa una clave

Solo quienes tengan el link Y la contraseña podrán acceder.
